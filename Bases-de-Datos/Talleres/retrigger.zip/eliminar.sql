\c postgres

DROP DATABASE eagtrigger;